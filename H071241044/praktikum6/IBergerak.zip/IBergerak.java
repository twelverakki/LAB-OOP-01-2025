public interface IBergerak {
    boolean mulai();
    boolean berhenti();
    double getKecepatan();
    void setKecepatan(double kecepatan);
}
