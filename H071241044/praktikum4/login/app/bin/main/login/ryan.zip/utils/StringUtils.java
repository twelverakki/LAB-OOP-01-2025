package login.utils;

public class StringUtils {
    public static String generateNickName(String fullName) {
        String[] parts = fullName.split(" ");
        String firstName = parts[0];
        return firstName.substring(0, Math.min(3, firstName.length()));
    }
}
